import React from "react";

export const muiAbtn = {
  backgroundColor: "#4b2980",
  color: "#fff",
  marginLeft: 16,
};

export const muibtn = {
  backgroundColor: "#4b2980",
  color: "#fff",
  marginTop: 20,
};
