import React from "react";
import "../css/styles.css";
export default function FacultyDashboard() {
  return (
    <div style={{ height: 760, width: "100%", padding: 30 }}>
    <h1>Evaluator Dashboard</h1>
    <p>Evalutorsa wqkejnwkkjasdjkasjkdnasdkjask</p>      
    </div>
  );
}
