// var express = require("express");
// var router = express.Router();
// var SOS = require("../../Controler/DocumentControllers/SOS");

// router.route("/add").post(SOS.Add);
// router.route("/show").get(SOS.Showall);
// router.route("/:id").delete(SOS.Delete).put(SOS.Update).get(SOS.ShowOne);

// module.exports = router;
